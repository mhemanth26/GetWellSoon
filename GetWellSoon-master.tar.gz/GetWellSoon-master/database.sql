-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db_health_centre
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Medical_Certificate`
--

DROP TABLE IF EXISTS `Medical_Certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Medical_Certificate` (
  `CftNo` int(15) NOT NULL,
  `IssueDate` date NOT NULL,
  `Name` varchar(255) NOT NULL,
  `PatientType` varchar(255) NOT NULL DEFAULT 'Student',
  `RollNo` varchar(255) NOT NULL,
  `Dependent` varchar(255) NOT NULL,
  `FromDate` date NOT NULL,
  `NoOfDays` int(4) NOT NULL,
  `Cause` varchar(1000) NOT NULL,
  `Doctor` varchar(255) NOT NULL,
  PRIMARY KEY (`CftNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Medical_Certificate`
--

LOCK TABLES `Medical_Certificate` WRITE;
/*!40000 ALTER TABLE `Medical_Certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `Medical_Certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Remarks`
--

DROP TABLE IF EXISTS `Remarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Remarks` (
  `Date` date NOT NULL,
  `Pat_Id` varchar(64) NOT NULL,
  `Dep_Name` varchar(256) NOT NULL,
  `Remark` varchar(1024) NOT NULL,
  `Entered_By` varchar(255) NOT NULL,
  KEY `Date` (`Date`,`Pat_Id`,`Dep_Name`,`Remark`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Remarks`
--

LOCK TABLES `Remarks` WRITE;
/*!40000 ALTER TABLE `Remarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `Remarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Temp_Medical_Certificate`
--

DROP TABLE IF EXISTS `Temp_Medical_Certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Temp_Medical_Certificate` (
  `CftNo` int(15) NOT NULL,
  `IssueDate` date NOT NULL,
  `Name` varchar(255) NOT NULL,
  `PatientType` varchar(255) NOT NULL DEFAULT 'Student',
  `RollNo` varchar(255) NOT NULL,
  `Dependent` varchar(255) NOT NULL,
  `FromDate` date NOT NULL,
  `NoOfDays` int(4) NOT NULL,
  `Cause` varchar(1000) NOT NULL,
  `Doctor` varchar(255) NOT NULL,
  PRIMARY KEY (`CftNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Temp_Medical_Certificate`
--

LOCK TABLES `Temp_Medical_Certificate` WRITE;
/*!40000 ALTER TABLE `Temp_Medical_Certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `Temp_Medical_Certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Transactions`
--

DROP TABLE IF EXISTS `Transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transactions` (
  `Type` varchar(30) NOT NULL DEFAULT 'Addition',
  `Transaction_Date` date NOT NULL,
  `Date` date NOT NULL,
  `BillNo` varchar(255) NOT NULL,
  `RecievedFrom` varchar(255) NOT NULL,
  `MedicineName` varchar(255) NOT NULL,
  `BatchNo` varchar(255) NOT NULL,
  `Expiry` date NOT NULL,
  `Qty` int(11) NOT NULL,
  `Cost` float NOT NULL,
  KEY `Medicine Name` (`MedicineName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transactions`
--

LOCK TABLES `Transactions` WRITE;
/*!40000 ALTER TABLE `Transactions` DISABLE KEYS */;
INSERT INTO `Transactions` VALUES ('Addition','2016-03-16','2015-08-22','2E09B005','Sunanda Associates','Alprax 0.25','2E09B005','2018-04-30',108,94.6),('Addition','2016-03-16','2014-09-12','1501001485','City Drugs','Althrocin 250','1501001485','2017-09-30',500,1728.5),('Addition','2016-04-05','2015-08-22','30070','Sunanda Assiciates','Alprax 0.25','ES852','2017-07-31',108,94.6),('Addition','2016-04-05','2015-08-22','30070','Sunanda Assiciates','Ampoxin kid','HAK15016','2017-04-30',150,219.75),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','ANTOXID','AA50036','2016-11-30',285,1251),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','ASCABIOL','AOA13029','2016-09-30',78,2355.6),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','AZIBACT 250','CRK045002AS','2016-03-31',960,7788.8),('Addition','2016-04-05','2015-08-28','30070','Sunanda Assiciates','AZIBACT KID','CTC045002AK','2017-04-30',30,120.5),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','BANDAGE CLOTH','12307','2016-03-31',18,2376),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','BECELAC FORTE','58CBF151','2016-09-30',500,1356),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','BETACARD 50','2172B002','2019-04-30',4200,11160),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','BETACARD AM','2173A022','2017-04-30',1400,1484),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','BETADINE SOLUTION','PB0185','2017-01-31',4,840),('Addition','2016-04-05','2016-03-31','2612','UDAYA PHARMACY','BICEF-500','BCFB0349','2017-10-31',200,720),('Addition','2016-04-05','2015-08-22','30070','Sunanda Assiciates','BRUFEN 200','54776D7','2016-09-30',3000,1080),('Addition','2016-04-05','2015-08-22','2610','UDAYA PHARMACY','CALAMINE LOTION','CME335','2017-05-31',27,1620),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','CALPOL 500','RG722','2018-05-31',5290,4200),('Addition','2016-04-05','2015-09-14','15023','ASHOK DRUGS','CALPOL SYRUP','FPH14G001','2016-06-30',107,2864.39),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','CEFALOC 200','CC512A','2017-05-31',200,2000),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','CHLOPHENIRAMIN MALIATE(ZEET)','DT702','2017-12-31',26,819),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','CHLOROMYCETIN APPLICAP','520-68006U','2016-12-31',6,348),('Addition','2016-04-05','2016-03-31','15023','City Drugs','CIPLOX TZ','2693255','2017-03-31',1400,12127),('Addition','2016-04-05','2015-09-14','15023','City Drugs','CLOPITAB-75','J501395','2016-10-31',200,926.4),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','COTTON 500GM','15075','2018-03-31',14,1848),('Addition','2016-04-05','2014-09-24','2538','UDAYA PHARMACY','DAONIL','0214009','2016-12-31',600,585),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','DERPHYLLIN RETARD 150','ZHR2587','2018-05-31',3500,1785),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','DETTOL 500ML','D3052','2016-01-31',21,1995),('Addition','2016-04-05','2015-08-22','30070','Sunanda Assiciates','DEWAX(WAXONIL)EAR DROPS','SW-189','2017-11-30',8,350.8),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','DEXTROSE 5 %','500407','2018-02-28',5,125),('Addition','2016-04-05','2015-08-25','8405','ASHOK DRUGS','DEXTROSE SALAINE','34923','2016-04-30',3,77.4),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','DICI-K','DK1501','2018-02-28',3100,7378),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','DIGENE','530020D7','2018-04-30',1452,1068),('Addition','2016-04-05','2016-03-31','15023C','City Drugs','DILONAC SP','CT15520','2017-06-30',600,3281),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 10CC','527105JCI','2020-06-30',47,231),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 2CC','528021SL1','2020-06-30',1200,3600),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 5CC','530052JNI','2020-06-30',345,1208),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','DOMSTAL.DT','2G27B022','2018-03-31',100,206),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','DOXY-1','6525','2017-01-31',1200,7560),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','ECOSPRIN AV 75','APA15115','2016-11-30',200,450),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','ECOSPRIN-75','041006016','2017-05-31',700,203),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','ELECTRAL POWDER','ELS5043','2017-03-31',150,2227.75),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','ENACE-5','ENB4001A','2016-05-31',600,1602),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','ETOGEN-P','PDVAC02','2016-12-31',600,3497),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','EUCLIDE-M','150145','2018-02-28',500,3750),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','EVION 400','G03814315','2017-06-30',800,1216),('Addition','2016-04-05','2016-03-31','15023','City Drugs','F-PAN 40','PBDAG02','2016-09-30',500,3193),('Addition','2016-04-05','2016-03-31','15023','City Drugs','FEFOL Z','MN209','2016-04-30',1050,6153),('Addition','2016-04-05','2016-03-31','15023','City Drugs','FLANZEN-10(BIDANZEN FORTE)','FZM1502','2017-02-28',800,7551),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','FOLVITE','50120','2016-08-31',170,208),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','FORMIN SR 500(GLYCEPHAGE)','5131545','2018-05-31',8550,6092),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','FREZIUM-5','A150010','2018-04-30',320,1832),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','GAUZE','260','2018-03-31',11,1320),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','GERBISA','AT14480','2016-07-31',160,168),('Addition','2016-04-05','2016-03-31','15023','City Drugs','GLADER-1','3500448','2017-01-31',1500,5010),('Addition','2016-04-05','2016-03-31','15023','City Drugs','GLADER-2','J403143','2016-10-31',900,4406),('Addition','2016-04-05','2016-03-31','2634','UDAYA PHARMACY','GLOVES','128','2018-08-31',125,500),('Addition','2016-04-05','2016-03-31','2636','UDAYA PHARMACY','GLUCORYL -M1','5132549','2017-08-31',3400,22100),('Addition','2016-04-05','2016-03-31','15023','UDAYA PHARMACY','GLUCORYL -M2','5130747','2017-03-31',800,5395),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','GLYCERIN','147','2018-03-31',2,200),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','HYDROGEN PERROXIDE','RH494','2016-12-31',11,242),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','I.V.SET','DCV15007','2018-03-31',14,190),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ T. TOXOID','017A4012B','2017-10-31',110,1074),('Addition','2016-04-05','2016-03-31','15023','City Drugs','INJ. FEBRINIL','FCN1419','2018-04-30',35,333),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ. HUMAN MIXTARD','B50933','2017-09-30',52,6552),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ.CYCLOPAM','CDX3F52','2017-05-31',30,167),('Addition','2016-04-05','2016-03-31','15023','City Drugs','INJ.KETANOV','9010694','2017-01-31',40,792),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ.NEUROBION','G33118014','2016-02-29',70,486),('Addition','2016-04-05','2016-03-31','15023','City Drugs','INJ.PANTOCID','1122','2016-10-31',3,123),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ.PERINORM','GE185021R','2018-02-28',55,194),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','INJ.VOVERAN','155035SP','2016-10-31',10,159),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','LASIX','A150028','2018-04-30',200,70),('Addition','2016-04-05','2016-03-31','15023','City Drugs','LEVOSTRA 500','CT15125','2017-01-31',900,5981),('Addition','2016-04-05','2016-03-31','2638','UDAYA PHARMACY','LIT M','ABT716','2016-07-31',200,1160),('Addition','2016-04-05','2016-03-31','15023','City Drugs','LIVONITRIN 5','SPK14634','2017-11-30',800,1836),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','MACPOD C.V','CCE6520A','2016-10-31',200,2800),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','MEFTAL SPAS','YMS515110','2018-05-31',250,723),('Addition','2016-04-05','2016-03-31','2643','UDAYA PHARMACY','MEGAPEN','M673F015','2017-05-31',600,1800),('Addition','2016-04-05','2016-03-31','15023','ASHOK DRUGS','METROGYL 200','AM24035','2018-04-30',1005,394),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','MICROPEC','130921','2018-08-31',30,570),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','NEBISTAR-5','NB50510','2017-04-30',200,1368),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','NEEDLE DISPO.','22582D','2020-04-30',800,1200),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','NEOSPORIN OINTMENT','BB464','2016-10-31',2,51),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','NEOSPORIN POWDER','BD413','2016-11-30',5,201),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','NEUROBION FORTE','13615','2016-11-30',2250,1575),('Addition','2016-04-05','2014-09-19','7774','ASHOK DRUGS','NICARDIA RETARD 10 MG','KCJ4022','2017-02-28',920,4766.82),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','NOBLE GEL','90010','2016-09-30',95,1805),('Addition','2016-04-05','2016-03-31','2624','UDAYA PHARMACY','NORMAL SALINE','101503548','2018-03-31',5,130),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','OCCUVIR 800','DFT5061','2017-05-31',175,3765),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','OMEZ-10','E500475','2018-04-30',1400,3738),('Addition','2016-04-05','2016-03-31','30070','Sunanda Associates','ORINASE NASAL DROPS','EPN15B01','2017-04-30',15,668),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','OSTEOCAL 500','PDVAA03','2017-05-31',1850,5428),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','OTOBIOTIC EAR DROPS','OS127','2016-08-31',7,244),('Addition','2016-04-05','2016-03-31','2612','UDAYA PHARMACY','PERMITE CREAM','G28W','2017-04-30',6,330),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','PLASTER ADHESIVE','15A29','2019-02-28',19,3990),('Addition','2016-04-05','2016-03-31','15023','City Drugs','RAMISTAR 5','J501179','2017-03-31',500,2459),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','RARICAP','BB15017','2016-12-31',1800,5792),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','REFRESH  EYE DROPS','PTO422','2017-05-31',8,1525),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','RELAXYL OINTMENT','510','2017-04-30',54,2214),('Addition','2016-04-05','2016-03-31','14265','City Drugs','REVAS-50','1401001021','2016-04-30',1000,3918),('Addition','2016-04-05','2016-03-31','14265','City Drugs','REVAS-H','J15024','2016-04-30',4000,22344),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','RIBOFLAVINE','R15421106','2018-04-30',500,88),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','SALBETOL 2 MG','STT5032','2018-02-28',800,106),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','SCALP VEIN SET','51332','2018-03-31',7,56),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','SENSICLAV ','JAB567A','2017-04-30',3180,39750),('Addition','2016-04-05','2016-03-31','2624','UDAYA PHARMACY','SILVEREX CREAM','7003215','2017-04-30',2,628),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','SORBITRATE 10 MG','SBB5009','2018-03-31',7500,4653),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','SURGICAL SPIRIT','97','2018-05-31',6,360),('Addition','2016-04-05','2016-03-31','35168','Sunanda Assiciates','TAB. PERINORM','GDO95005AS','2018-04-30',1400,1382),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','TEARS NATURA FORTE','235448F','2017-01-31',3,417),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','TELDAY-H','TSTF15017S','2017-02-28',400,3076),('Addition','2016-04-05','2016-03-31','2631','UDAYA PHARMACY','TELMA AM','18150415','2017-03-31',150,1500),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','TERACORT-8','PDVAB01','2016-07-31',50,319),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','TIMOLET EYE DROPS','6441','2016-09-30',6,384),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','TOLAGIN -4','TSTR5009','2018-03-31',200,2320),('Addition','2016-04-05','2016-03-31','15023','City Drugs','TONACT-10','J402901','2016-10-31',5400,29304),('Addition','2016-04-05','2016-03-31','2610','UDAYA PHARMACY','TOPAZ-100','1253','2017-04-30',100,1100),('Addition','2016-04-05','2016-03-31','8405','ASHOK DRUGS','TROFIL','TF1513','2018-05-31',1200,2742),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','TUSQ-D','BT1530','2016-11-30',33,1980),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','VALIUM 2','VLA5001','2018-12-31',190,257),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','VALPARIN CHRONO 300','2915028','2018-05-31',800,4760),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','VERTIN-8','RBIA5004','2018-02-28',100,445),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','WHITEFIELDS OINT','462','2018-06-30',4,640),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','WOKADINE OINT.','0800051','2017-03-31',13,1607),('Addition','2016-04-05','2016-03-31','2611','UDAYA PHARMACY','WYSOLONE 5 MG','39628','2017-04-30',360,212),('Addition','2016-04-05','2016-03-31','30070','Sunanda Assiciates','ZERDOL 100','CSW85002A','2017-03-31',300,748),('Addition','2016-04-05','2016-03-31','15023','City Drugs','ZETAL 400','P382','2016-08-31',300,2664),('Addition','2016-04-05','2016-04-01','15023','City Drugs','Amlopdepine( Lupidep)','LN15011','2017-04-30',2600,4836);
/*!40000 ALTER TABLE `Transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Yearly_Report`
--

DROP TABLE IF EXISTS `Yearly_Report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Yearly_Report` (
  `Year` int(4) NOT NULL AUTO_INCREMENT,
  `OpeningBal` float NOT NULL,
  `Purchase` float DEFAULT NULL,
  `Consumption` float DEFAULT NULL,
  `ClosingBal` float DEFAULT NULL,
  PRIMARY KEY (`Year`)
) ENGINE=InnoDB AUTO_INCREMENT=2017 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Yearly_Report`
--

LOCK TABLES `Yearly_Report` WRITE;
/*!40000 ALTER TABLE `Yearly_Report` DISABLE KEYS */;
INSERT INTO `Yearly_Report` VALUES (2011,0,0,0,0),(2012,0,0,0,0),(2013,0,0,0,0),(2014,0,0,0,0),(2015,0,7080.32,0,7080.32),(2016,7080.32,353522,0,360602);
/*!40000 ALTER TABLE `Yearly_Report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultation` (
  `PatientId` varchar(11) NOT NULL,
  `Dependent` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Cause` varchar(255) NOT NULL,
  `MedicineName` varchar(255) NOT NULL,
  `Timings` varchar(25) NOT NULL,
  `NoOfDays` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation`
--

LOCK TABLES `consultation` WRITE;
/*!40000 ALTER TABLE `consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_stock`
--

DROP TABLE IF EXISTS `medicine_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicine_stock` (
  `Date` date NOT NULL,
  `BillNo` varchar(255) NOT NULL,
  `RecievedFrom` varchar(255) NOT NULL,
  `MedicineName` varchar(255) NOT NULL,
  `BatchNo` varchar(255) NOT NULL,
  `Expiry` date NOT NULL,
  `Qty` int(11) NOT NULL,
  `Cost` float NOT NULL,
  PRIMARY KEY (`MedicineName`,`BatchNo`),
  KEY `Medicine Name` (`MedicineName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine_stock`
--

LOCK TABLES `medicine_stock` WRITE;
/*!40000 ALTER TABLE `medicine_stock` DISABLE KEYS */;
INSERT INTO `medicine_stock` VALUES ('2015-08-22','30070','Sunanda Associates','Alprax 0.25','2E09B005','2018-04-30',108,94.6),('2015-08-22','30070','Sunanda Assiciates','Alprax 0.25','ES852','2017-07-31',108,94.6),('2014-09-12','14265','City Drugs','Althrocin 250','1501001485','2017-09-30',500,1728.5),('2016-04-01','15023','City Drugs','Amlopdepine( Lupidep)','LN15011','2017-04-30',2600,4836),('2015-08-22','30070','Sunanda Assiciates','Ampoxin kid','HAK15016','2017-04-30',150,219.75),('2016-03-31','30070','Sunanda Assiciates','ANTOXID','AA50036','2016-11-30',285,1251),('2016-03-31','8405','ASHOK DRUGS','ASCABIOL','AOA13029','2016-09-30',78,2355.6),('2016-03-31','30070','Sunanda Assiciates','AZIBACT 250','CRK045002AS','2016-03-31',960,7788.8),('2015-08-28','30070','Sunanda Assiciates','AZIBACT KID','CTC045002AK','2017-04-30',30,120.5),('2016-03-31','8405','ASHOK DRUGS','BANDAGE CLOTH','12307','2016-03-31',18,2376),('2016-03-31','30070','Sunanda Assiciates','BECELAC FORTE','58CBF151','2016-09-30',500,1356),('2016-03-31','30070','Sunanda Assiciates','BETACARD 50','2172B002','2019-04-30',4200,11160),('2016-03-31','30070','Sunanda Assiciates','BETACARD AM','2173A022','2017-04-30',1400,1484),('2016-03-31','2610','UDAYA PHARMACY','BETADINE SOLUTION','PB0185','2017-01-31',4,840),('2016-03-31','2612','UDAYA PHARMACY','BICEF-500','BCFB0349','2017-10-31',200,720),('2015-08-22','30070','Sunanda Assiciates','BRUFEN 200','54776D7','2016-09-30',3000,1080),('2015-08-22','2610','UDAYA PHARMACY','CALAMINE LOTION','CME335','2017-05-31',27,1620),('2016-03-31','30070','Sunanda Assiciates','CALPOL 500','RG722','2018-05-31',5290,4200),('2015-09-14','15023','ASHOK DRUGS','CALPOL SYRUP','FPH14G001','2016-06-30',107,2864.39),('2016-03-31','2611','UDAYA PHARMACY','CEFALOC 200','CC512A','2017-05-31',200,2000),('2016-03-31','8405','ASHOK DRUGS','CHLOPHENIRAMIN MALIATE(ZEET)','DT702','2017-12-31',26,819),('2016-03-31','2610','UDAYA PHARMACY','CHLOROMYCETIN APPLICAP','520-68006U','2016-12-31',6,348),('2016-03-31','15023','City Drugs','CIPLOX TZ','2693255','2017-03-31',1400,12127),('2015-09-14','15023','City Drugs','CLOPITAB-75','J501395','2016-10-31',200,926.4),('2016-03-31','2610','UDAYA PHARMACY','COTTON 500GM','15075','2018-03-31',14,1848),('2014-09-24','2538','UDAYA PHARMACY','DAONIL','0214009','2016-12-31',600,585),('2016-03-31','2611','UDAYA PHARMACY','DERPHYLLIN RETARD 150','ZHR2587','2018-05-31',3500,1785),('2016-03-31','8405','ASHOK DRUGS','DETTOL 500ML','D3052','2016-01-31',21,1995),('2015-08-22','30070','Sunanda Assiciates','DEWAX(WAXONIL)EAR DROPS','SW-189','2017-11-30',8,350.8),('2016-03-31','2610','UDAYA PHARMACY','DEXTROSE 5 %','500407','2018-02-28',5,125),('2015-08-25','8405','ASHOK DRUGS','DEXTROSE SALAINE','34923','2016-04-30',3,77.4),('2016-03-31','8405','ASHOK DRUGS','DICI-K','DK1501','2018-02-28',3100,7378),('2016-03-31','30070','Sunanda Assiciates','DIGENE','530020D7','2018-04-30',1452,1068),('2016-03-31','15023C','City Drugs','DILONAC SP','CT15520','2017-06-30',600,3281),('2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 10CC','527105JCI','2020-06-30',47,231),('2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 2CC','528021SL1','2020-06-30',1200,3600),('2016-03-31','8405','ASHOK DRUGS','DISP.SYRINGE 5CC','530052JNI','2020-06-30',345,1208),('2016-03-31','30070','Sunanda Assiciates','DOMSTAL.DT','2G27B022','2018-03-31',100,206),('2016-03-31','2610','UDAYA PHARMACY','DOXY-1','6525','2017-01-31',1200,7560),('2016-03-31','2611','UDAYA PHARMACY','ECOSPRIN AV 75','APA15115','2016-11-30',200,450),('2016-03-31','2610','UDAYA PHARMACY','ECOSPRIN-75','041006016','2017-05-31',700,203),('2016-03-31','8405','ASHOK DRUGS','ELECTRAL POWDER','ELS5043','2017-03-31',150,2227.75),('2016-03-31','30070','Sunanda Assiciates','ENACE-5','ENB4001A','2016-05-31',600,1602),('2016-03-31','30070','Sunanda Assiciates','ETOGEN-P','PDVAC02','2016-12-31',600,3497),('2016-03-31','2611','UDAYA PHARMACY','EUCLIDE-M','150145','2018-02-28',500,3750),('2016-03-31','30070','Sunanda Assiciates','EVION 400','G03814315','2017-06-30',800,1216),('2016-03-31','15023','City Drugs','F-PAN 40','PBDAG02','2016-09-30',500,3193),('2016-03-31','15023','City Drugs','FEFOL Z','MN209','2016-04-30',1050,6153),('2016-03-31','15023','City Drugs','FLANZEN-10(BIDANZEN FORTE)','FZM1502','2017-02-28',800,7551),('2016-03-31','30070','Sunanda Assiciates','FOLVITE','50120','2016-08-31',170,208),('2016-03-31','2610','UDAYA PHARMACY','FORMIN SR 500(GLYCEPHAGE)','5131545','2018-05-31',8550,6092),('2016-03-31','30070','Sunanda Assiciates','FREZIUM-5','A150010','2018-04-30',320,1832),('2016-03-31','8405','ASHOK DRUGS','GAUZE','260','2018-03-31',11,1320),('2016-03-31','2611','UDAYA PHARMACY','GERBISA','AT14480','2016-07-31',160,168),('2016-03-31','15023','City Drugs','GLADER-1','3500448','2017-01-31',1500,5010),('2016-03-31','15023','City Drugs','GLADER-2','J403143','2016-10-31',900,4406),('2016-03-31','2634','UDAYA PHARMACY','GLOVES','128','2018-08-31',125,500),('2016-03-31','2636','UDAYA PHARMACY','GLUCORYL -M1','5132549','2017-08-31',3400,22100),('2016-03-31','15023','UDAYA PHARMACY','GLUCORYL -M2','5130747','2017-03-31',800,5395),('2016-03-31','2610','UDAYA PHARMACY','GLYCERIN','147','2018-03-31',2,200),('2016-03-31','2610','UDAYA PHARMACY','HYDROGEN PERROXIDE','RH494','2016-12-31',11,242),('2016-03-31','8405','ASHOK DRUGS','I.V.SET','DCV15007','2018-03-31',14,190),('2016-03-31','30070','Sunanda Assiciates','INJ T. TOXOID','017A4012B','2017-10-31',110,1074),('2016-03-31','15023','City Drugs','INJ. FEBRINIL','FCN1419','2018-04-30',35,333),('2016-03-31','30070','Sunanda Assiciates','INJ. HUMAN MIXTARD','B50933','2017-09-30',52,6552),('2016-03-31','30070','Sunanda Assiciates','INJ.CYCLOPAM','CDX3F52','2017-05-31',30,167),('2016-03-31','15023','City Drugs','INJ.KETANOV','9010694','2017-01-31',40,792),('2016-03-31','30070','Sunanda Assiciates','INJ.NEUROBION','G33118014','2016-02-29',70,486),('2016-03-31','15023','City Drugs','INJ.PANTOCID','1122','2016-10-31',3,123),('2016-03-31','30070','Sunanda Assiciates','INJ.PERINORM','GE185021R','2018-02-28',55,194),('2016-03-31','30070','Sunanda Assiciates','INJ.VOVERAN','155035SP','2016-10-31',10,159),('2016-03-31','2610','UDAYA PHARMACY','LASIX','A150028','2018-04-30',200,70),('2016-03-31','15023','City Drugs','LEVOSTRA 500','CT15125','2017-01-31',900,5981),('2016-03-31','2638','UDAYA PHARMACY','LIT M','ABT716','2016-07-31',200,1160),('2016-03-31','15023','City Drugs','LIVONITRIN 5','SPK14634','2017-11-30',800,1836),('2016-03-31','2611','UDAYA PHARMACY','MACPOD C.V','CCE6520A','2016-10-31',200,2800),('2016-03-31','2611','UDAYA PHARMACY','MEFTAL SPAS','YMS515110','2018-05-31',250,723),('2016-03-31','2643','UDAYA PHARMACY','MEGAPEN','M673F015','2017-05-31',600,1800),('2016-03-31','15023','ASHOK DRUGS','METROGYL 200','AM24035','2018-04-30',1005,394),('2016-03-31','2610','UDAYA PHARMACY','MICROPEC','130921','2018-08-31',30,570),('2016-03-31','30070','Sunanda Assiciates','NEBISTAR-5','NB50510','2017-04-30',200,1368),('2016-03-31','8405','ASHOK DRUGS','NEEDLE DISPO.','22582D','2020-04-30',800,1200),('2016-03-31','30070','Sunanda Assiciates','NEOSPORIN OINTMENT','BB464','2016-10-31',2,51),('2016-03-31','30070','Sunanda Assiciates','NEOSPORIN POWDER','BD413','2016-11-30',5,201),('2016-03-31','2610','UDAYA PHARMACY','NEUROBION FORTE','13615','2016-11-30',2250,1575),('2014-09-19','7774','ASHOK DRUGS','NICARDIA RETARD 10 MG','KCJ4022','2017-02-28',920,4766.82),('2016-03-31','2610','UDAYA PHARMACY','NOBLE GEL','90010','2016-09-30',95,1805),('2016-03-31','2624','UDAYA PHARMACY','NORMAL SALINE','101503548','2018-03-31',5,130),('2016-03-31','8405','ASHOK DRUGS','OCCUVIR 800','DFT5061','2017-05-31',175,3765),('2016-03-31','30070','Sunanda Assiciates','OMEZ-10','E500475','2018-04-30',1400,3738),('2016-03-31','30070','Sunanda Associates','ORINASE NASAL DROPS','EPN15B01','2017-04-30',15,668),('2016-03-31','30070','Sunanda Assiciates','OSTEOCAL 500','PDVAA03','2017-05-31',1850,5428),('2016-03-31','30070','Sunanda Assiciates','OTOBIOTIC EAR DROPS','OS127','2016-08-31',7,244),('2016-03-31','2612','UDAYA PHARMACY','PERMITE CREAM','G28W','2017-04-30',6,330),('2016-03-31','2611','UDAYA PHARMACY','PLASTER ADHESIVE','15A29','2019-02-28',19,3990),('2016-03-31','15023','City Drugs','RAMISTAR 5','J501179','2017-03-31',500,2459),('2016-03-31','30070','Sunanda Assiciates','RARICAP','BB15017','2016-12-31',1800,5792),('2016-03-31','30070','Sunanda Assiciates','REFRESH  EYE DROPS','PTO422','2017-05-31',8,1525),('2016-03-31','2611','UDAYA PHARMACY','RELAXYL OINTMENT','510','2017-04-30',54,2214),('2016-03-31','14265','City Drugs','REVAS-50','1401001021','2016-04-30',1000,3918),('2016-03-31','14265','City Drugs','REVAS-H','J15024','2016-04-30',4000,22344),('2016-03-31','8405','ASHOK DRUGS','RIBOFLAVINE','R15421106','2018-04-30',500,88),('2016-03-31','8405','ASHOK DRUGS','SALBETOL 2 MG','STT5032','2018-02-28',800,106),('2016-03-31','2611','UDAYA PHARMACY','SCALP VEIN SET','51332','2018-03-31',7,56),('2016-03-31','2611','UDAYA PHARMACY','SENSICLAV ','JAB567A','2017-04-30',3180,39750),('2016-03-31','2624','UDAYA PHARMACY','SILVEREX CREAM','7003215','2017-04-30',2,628),('2016-03-31','30070','Sunanda Assiciates','SORBITRATE 10 MG','SBB5009','2018-03-31',7500,4653),('2016-03-31','8405','ASHOK DRUGS','SURGICAL SPIRIT','97','2018-05-31',6,360),('2016-03-31','35168','Sunanda Assiciates','TAB. PERINORM','GDO95005AS','2018-04-30',1400,1382),('2016-03-31','30070','Sunanda Assiciates','TEARS NATURA FORTE','235448F','2017-01-31',3,417),('2016-03-31','30070','Sunanda Assiciates','TELDAY-H','TSTF15017S','2017-02-28',400,3076),('2016-03-31','2631','UDAYA PHARMACY','TELMA AM','18150415','2017-03-31',150,1500),('2016-03-31','30070','Sunanda Assiciates','TERACORT-8','PDVAB01','2016-07-31',50,319),('2016-03-31','2611','UDAYA PHARMACY','TIMOLET EYE DROPS','6441','2016-09-30',6,384),('2016-03-31','2610','UDAYA PHARMACY','TOLAGIN -4','TSTR5009','2018-03-31',200,2320),('2016-03-31','15023','City Drugs','TONACT-10','J402901','2016-10-31',5400,29304),('2016-03-31','2610','UDAYA PHARMACY','TOPAZ-100','1253','2017-04-30',100,1100),('2016-03-31','8405','ASHOK DRUGS','TROFIL','TF1513','2018-05-31',1200,2742),('2016-03-31','2611','UDAYA PHARMACY','TUSQ-D','BT1530','2016-11-30',33,1980),('2016-03-31','30070','Sunanda Assiciates','VALIUM 2','VLA5001','2018-12-31',190,257),('2016-03-31','30070','Sunanda Assiciates','VALPARIN CHRONO 300','2915028','2018-05-31',800,4760),('2016-03-31','30070','Sunanda Assiciates','VERTIN-8','RBIA5004','2018-02-28',100,445),('2016-03-31','2611','UDAYA PHARMACY','WHITEFIELDS OINT','462','2018-06-30',4,640),('2016-03-31','30070','Sunanda Assiciates','WOKADINE OINT.','0800051','2017-03-31',13,1607),('2016-03-31','2611','UDAYA PHARMACY','WYSOLONE 5 MG','39628','2017-04-30',360,212),('2016-03-31','30070','Sunanda Assiciates','ZERDOL 100','CSW85002A','2017-03-31',300,748),('2016-03-31','15023','City Drugs','ZETAL 400','P382','2016-08-31',300,2664);
/*!40000 ALTER TABLE `medicine_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `Patient_Id` varchar(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Dependent` varchar(255) NOT NULL DEFAULT '',
  `Sex` varchar(255) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Ph.No` varchar(255) DEFAULT NULL,
  `Alt.Ph.No` varchar(255) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `PermanentAddress` text,
  `LocalAddress` text,
  PRIMARY KEY (`Patient_Id`,`Name`,`Dependent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES ('1','test','test','Male',12,'9876543210','','2016-03-14','NIT Calicut','NIT Calicut');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp_consultation`
--

DROP TABLE IF EXISTS `temp_consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp_consultation` (
  `PatientId` varchar(11) NOT NULL,
  `Dependent` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Cause` varchar(255) NOT NULL,
  `MedicineName` varchar(255) NOT NULL,
  `Timings` varchar(25) NOT NULL,
  `NoOfDays` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_consultation`
--

LOCK TABLES `temp_consultation` WRITE;
/*!40000 ALTER TABLE `temp_consultation` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_consultation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp_medicine_stock`
--

DROP TABLE IF EXISTS `temp_medicine_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp_medicine_stock` (
  `Date` date NOT NULL,
  `BillNo` varchar(255) NOT NULL,
  `RecievedFrom` varchar(255) NOT NULL,
  `MedicineName` varchar(255) NOT NULL,
  `BatchNo` varchar(255) NOT NULL,
  `Expiry` date DEFAULT '3000-01-01',
  `Qty` int(11) NOT NULL,
  `Cost` float NOT NULL,
  PRIMARY KEY (`MedicineName`,`BatchNo`),
  KEY `Medicine Name` (`MedicineName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_medicine_stock`
--

LOCK TABLES `temp_medicine_stock` WRITE;
/*!40000 ALTER TABLE `temp_medicine_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_medicine_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `Name` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `SecQn1` text NOT NULL,
  `Ans1` varchar(255) NOT NULL,
  `SecQn2` text NOT NULL,
  `Ans2` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL DEFAULT 'Doctor',
  PRIMARY KEY (`UserName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('Abraham','abraham','834b34f16f451e00f268dd5c8c81d16e3c020275','Where do you work?','b8bec6726249c8e6e903b407706005f5b4f2c235','How old are you?','12c6fc06c99a462375eeb3f43dfd832b08ca9e17','labadmin'),('Administrator','admin','3ebade3f237fa9e0558b5d2bba94f7de5da68ca8','admin','3ebade3f237fa9e0558b5d2bba94f7de5da68ca8','admin','3ebade3f237fa9e0558b5d2bba94f7de5da68ca8','admin'),('A A Celine','celine','1f0160076c9f42a157f0a8f0dcc68e02ff69045b','Where do you work?','b8bec6726249c8e6e903b407706005f5b4f2c235','Where is health centre?','d4e5c3ad5613eac9d3923e669f336fe13cefd86d','Doctor');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-10 16:49:20
