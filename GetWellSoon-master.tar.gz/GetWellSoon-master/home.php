<html>
<head>
    <title>Admin Home Page</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="icon" href="images/Logo---307x275.png">
</head>
<body background="images/1.jpg">
    <div class="container">
        <div class="head">
            <img class="image1" src="images/Logo---307x275.png">
            <div class="sub-head1">
                NITC HEALTH CENTER
            </div>
            <a class="sub-head2" href="features/report.php">REPORTS</a>
            <a class="sub-head2" href="profile.php">PROFILE</a>
            <a class="sub-head2" href="lib/logout.php">LOGOUT</a>
        </div>
        <div class="body">
            <a href="features/add_stock.php">
                <img src="images/add stock.png"><br>
            </a>
            <a href="features/remove_stock.php">
                <img src="images/remove stock.png"><br>
            </a>
            <a href="features/view_stock.php">
                <img src="images/view stock.png"><br>
            </a>
        </div>
    </div>
</body>
</html>
