<?php
header("Location: ..");
?>